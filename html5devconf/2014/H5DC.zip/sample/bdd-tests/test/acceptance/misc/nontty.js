
describe('tests for non-tty', function(){
  it('should pass', function(){

  })

  it('should fail', function(){
    throw new Error('oh noes')
  })
})
