
describe('grep', function(){
  describe('fast', function(){
    it('should run fast', function(){

    })

    it('should run fast again', function(){

    })
  })

  describe('slow', function(){
    it('should run slow', function(done){
      setTimeout(done, 1000);
    })

    it('should run slow again', function(done){
      setTimeout(done, 1000);
    })
  })
})
